#ifndef INA226_WE_CONFIG_H_
#define INA226_WE_CONFIG_H_
/* Uncomment the following line to use alternative enum names for measure modes, 
e.g. if you want to use INA219_WE in parallel. */
//#define INA226_WE_COMPATIBILITY_MODE_

#endif